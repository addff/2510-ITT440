#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <mysql/mysql.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>

// CHANGE THIS TO "server4" and 6004 for the second C server
char *SERVER_ID = "server4";
int PORT = 6004;

int current_points = 0;
volatile int running = 1;

void log_to_db(char *msg) {
    MYSQL *con = mysql_init(NULL);
    if(con && mysql_real_connect(con, "db", "root", "rootpassword", "itt440_db", 0, NULL, 0)) {
        char log_q[512];
        sprintf(log_q, "INSERT INTO server_logs (server_id, message_sent) VALUES ('%s', '%s')", SERVER_ID, msg);
        mysql_query(con, log_q);
        mysql_close(con);
        printf("[%s] DB Log: %s\n", SERVER_ID, msg);
    }
}

void handle_shutdown(int sig) {
    running = 0;
}

void *db_loop(void *arg) {
    sleep(15);
    while(running) {
        MYSQL *con = mysql_init(NULL);
        if(con && mysql_real_connect(con, "db", "root", "rootpassword", "itt440_db", 0, NULL, 0)) {
            char q[200];
            sprintf(q, "UPDATE server_stats SET points=points+1, datetime_stamp=NOW() WHERE user='%s'", SERVER_ID);
            mysql_query(con, q);
            
            sprintf(q, "SELECT points FROM server_stats WHERE user='%s'", SERVER_ID);
            mysql_query(con, q);
            MYSQL_RES *res = mysql_store_result(con);
            MYSQL_ROW row = mysql_fetch_row(res);
            if(row) current_points = atoi(row[0]);
            
            mysql_close(con);
            printf("[%s] Stats Updated: %d\n", SERVER_ID, current_points);
        }
        sleep(30);
    }
    return NULL;
}

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    signal(SIGTERM, handle_shutdown);
    signal(SIGINT, handle_shutdown);

    pthread_t tid;
    pthread_create(&tid, NULL, db_loop, NULL);

    int server_fd, new_socket;
    struct sockaddr_in address;
    int opt = 1; 
    int addrlen = sizeof(address);
    
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
    
    // Timeout for loop check
    struct timeval tv;
    tv.tv_sec = 2; tv.tv_usec = 0;
    setsockopt(server_fd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);

    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);
    bind(server_fd, (struct sockaddr *)&address, sizeof(address));
    listen(server_fd, 3);
    printf("[%s] Listening on %d\n", SERVER_ID, PORT);

    while(running) {
        if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen)) >= 0) {
            char buf[20];
            sprintf(buf, "%d", current_points);
            send(new_socket, buf, strlen(buf), 0);
            close(new_socket);
            log_to_db(buf);
        }
    }

    char final_msg[100];
    sprintf(final_msg, "Server Stopped. Final Count: %d", current_points);
    log_to_db(final_msg);
    return 0;
}