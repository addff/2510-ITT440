CREATE DATABASE IF NOT EXISTS itt440_db;
USE itt440_db;

CREATE TABLE IF NOT EXISTS server_stats (
    user VARCHAR(50) PRIMARY KEY,
    points INT DEFAULT 0,
    datetime_stamp DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS server_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    server_id VARCHAR(50),
    message_sent VARCHAR(255),
    log_time DATETIME DEFAULT CURRENT_TIMESTAMP
);

INSERT IGNORE INTO server_stats (user, points, datetime_stamp) VALUES ('server1', 0, NOW());
INSERT IGNORE INTO server_stats (user, points, datetime_stamp) VALUES ('server2', 0, NOW());
INSERT IGNORE INTO server_stats (user, points, datetime_stamp) VALUES ('server3', 0, NOW());
INSERT IGNORE INTO server_stats (user, points, datetime_stamp) VALUES ('server4', 0, NOW());