#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netdb.h>

// CHANGE THIS TO "server4", 6004, "Client4" for the second C client
char *TARGET = "server3";
int PORT = 6003;
char *CLIENT_ID = "Client3";

int main() {
    setvbuf(stdout, NULL, _IONBF, 0);
    int last_known = 0;
    
    sleep(10);
    printf("[%s] Started\n", CLIENT_ID);

    while(1) {
        int sock = socket(AF_INET, SOCK_STREAM, 0);
        struct hostent *server = gethostbyname(TARGET);
        struct sockaddr_in serv_addr;
        
        int connected = 0;

        if(server != NULL) {
            memset(&serv_addr, 0, sizeof(serv_addr));
            serv_addr.sin_family = AF_INET;
            bcopy((char *)server->h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
            serv_addr.sin_port = htons(PORT);
            
            if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) >= 0) {
                char buf[1024] = {0};
                if(read(sock, buf, 1024) > 0) {
                    last_known = atoi(buf);
                    printf("[%s] Received: %d\n", CLIENT_ID, last_known);
                    connected = 1;
                }
            }
        }

        if (!connected) {
            // REQUIREMENT: Show "Server Close" and "Last Count"
            printf("[%s] Server Closed/Unreachable. Last Count: %d\n", CLIENT_ID, last_known);
        }

        if(sock >= 0) close(sock);
        sleep(5);
    }
    return 0;
}