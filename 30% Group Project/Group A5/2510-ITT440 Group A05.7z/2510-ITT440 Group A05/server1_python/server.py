import socket
import threading
import time
import mysql.connector
import signal
import sys

# CHANGE THIS TO 'server2' and PORT 6002 for the second server
SERVER_ID = 'server1'
PORT = 6001
DB_HOST = 'db'

current_count = 0
running = True

def log_to_db(message):
    try:
        db = mysql.connector.connect(host=DB_HOST, user="root", password="rootpassword", database="itt440_db")
        cur = db.cursor()
        cur.execute("INSERT INTO server_logs (server_id, message_sent) VALUES (%s, %s)", (SERVER_ID, message))
        db.commit()
        db.close()
        print(f"[{SERVER_ID}] Logged: {message}")
    except:
        pass

def handle_shutdown(signum, frame):
    global running
    print(f"[{SERVER_ID}] Shutting down...")
    running = False
    log_to_db(f"Server Stopped. Final Count: {current_count}")
    sys.exit(0)

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT, handle_shutdown)

def db_loop():
    global current_count
    time.sleep(15)
    while running:
        try:
            conn = mysql.connector.connect(host=DB_HOST, user="root", password="rootpassword", database="itt440_db")
            cursor = conn.cursor()
            cursor.execute("UPDATE server_stats SET points = points + 1, datetime_stamp = NOW() WHERE user = %s", (SERVER_ID,))
            conn.commit()
            cursor.execute("SELECT points FROM server_stats WHERE user = %s", (SERVER_ID,))
            current_count = cursor.fetchone()[0]
            conn.close()
            print(f"[{SERVER_ID}] Updated Stats: {current_count}")
        except Exception as e:
            print(f"DB Error: {e}")
        time.sleep(30)

if __name__ == "__main__":
    t = threading.Thread(target=db_loop, daemon=True)
    t.start()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(('0.0.0.0', PORT))
    s.listen(5)
    s.settimeout(2.0)
    print(f"[{SERVER_ID}] Listening...")

    while running:
        try:
            try:
                client, addr = s.accept()
                msg = str(current_count)
                client.send(msg.encode())
                client.close()
                log_to_db(msg)
            except socket.timeout:
                continue
        except:
            pass