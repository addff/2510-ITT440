import socket
import time

# CHANGE THIS TO 'server2', PORT 6002, CLIENT_ID 'client2' for the second client
TARGET = 'server1'
PORT = 6001
CLIENT_ID = 'client1'

last_known_count = "0"
print(f"[{CLIENT_ID}] Started.")
time.sleep(10)

while True:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((TARGET, PORT))
        msg = s.recv(1024).decode()
        s.close()
        
        last_known_count = msg
        print(f"[{CLIENT_ID}] Received: {msg}")

    except Exception as e:
        # REQUIREMENT: Show "Server Close" and "Last Count"
        print(f"[{CLIENT_ID}] Server Closed/Unreachable. Last Count: {last_known_count}")
    
    time.sleep(5)